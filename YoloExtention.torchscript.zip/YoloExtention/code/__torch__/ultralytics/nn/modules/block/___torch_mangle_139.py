class C2f(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_127.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_130.Conv
  m : __torch__.torch.nn.modules.container.___torch_mangle_138.ModuleList
  def forward(self: __torch__.ultralytics.nn.modules.block.___torch_mangle_139.C2f,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    _0 = getattr(m, "0")
    cv1 = self.cv1
    _1 = (cv1).forward(argument_1, argument_2, )
    _2 = torch.split_with_sizes(_1, [64, 64], 1)
    _3, input, = _2
    _4 = [_3, input, (_0).forward(argument_1, input, )]
    input0 = torch.cat(_4, 1)
    return (cv2).forward(argument_1, input0, )
